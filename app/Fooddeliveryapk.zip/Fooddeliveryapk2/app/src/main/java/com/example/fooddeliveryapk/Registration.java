package com.example.fooddeliveryapk;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.android.material.textfield.TextInputLayout;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hbb20.CountryCodePicker;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.HashMap;

public class Registration extends AppCompatActivity {

    private TextInputLayout firstName, mobileNumber, Lastname, eMailidle, pwdrd, cpwdrd, LocalAddress, aarea, piiinCode;
    private Button signupho, emailbutt, Phonebutt;
    private Spinner state, Citys;
    private CountryCodePicker Country;
    private String firname, lasname, emaillid, passsword, confdpassword, mobile, house, Area, Pincode, role = "Customer", statee, cityy;
    private FirebaseAuth fAuth;
    private DatabaseReference databaseReference;
    private FirebaseDatabase firebaseDatabase;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);

        // Initialize UI elements
        firstName = findViewById(R.id.firstName);
        Lastname = findViewById(R.id.Lastname);
        eMailidle = findViewById(R.id.emailidle);
        pwdrd = findViewById(R.id.pwdrd);
        cpwdrd = findViewById(R.id.cpwdrd);
        mobileNumber = findViewById(R.id.mobileNumber);
        LocalAddress = findViewById(R.id.LocalAddress);
        aarea = findViewById(R.id.aarea);
        piiinCode = findViewById(R.id.piiincode);
        signupho = findViewById(R.id.signupho);
        emailbutt = findViewById(R.id.emailbutt);
        Phonebutt = findViewById(R.id.Phonebutt);
        Country = findViewById(R.id.Country);
        state = findViewById(R.id.state);
        Citys = findViewById(R.id.Citys);

        // Set up spinners
        ArrayAdapter<CharSequence> stateAdapter = ArrayAdapter.createFromResource(this,
                R.array.indian_states, android.R.layout.simple_spinner_item);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        state.setAdapter(stateAdapter);

        ArrayAdapter<CharSequence> cityAdapter = ArrayAdapter.createFromResource(this,
                R.array.indian_cities, android.R.layout.simple_spinner_item);
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Citys.setAdapter(cityAdapter);

        // Initialize Firebase
        fAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance(); // Initialize FirebaseDatabase
        databaseReference = firebaseDatabase.getReference("Customer");

        // Set up listeners
        signupho.setOnClickListener(v -> {
            // Collect data
            firname = firstName.getEditText().getText().toString().trim();
            lasname = Lastname.getEditText().getText().toString().trim();
            emaillid = eMailidle.getEditText().getText().toString().trim();
            mobile = mobileNumber.getEditText().getText().toString().trim();
            passsword = pwdrd.getEditText().getText().toString().trim();
            confdpassword = cpwdrd.getEditText().getText().toString().trim();
            Area = aarea.getEditText().getText().toString().trim();
            house = LocalAddress.getEditText().getText().toString().trim();
            Pincode = piiinCode.getEditText().getText().toString().trim();
            statee = state.getSelectedItem().toString();
            cityy = Citys.getSelectedItem().toString();

            if (isValid()) {
                mDialog = new ProgressDialog(Registration.this);
                mDialog.setCancelable(false);
                mDialog.setCanceledOnTouchOutside(false);
                mDialog.setMessage("Registration in progress, please wait...");
                mDialog.show();

                fAuth.createUserWithEmailAndPassword(emaillid, passsword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            String userId = fAuth.getCurrentUser().getUid();
                            databaseReference = firebaseDatabase.getReference("User").child(userId);
                            HashMap<String, String> userHashMap = new HashMap<>();
                            userHashMap.put("Role", role);
                            databaseReference.setValue(userHashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        HashMap<String, String> customerHashMap = new HashMap<>();
                                        customerHashMap.put("Mobile No", mobile);
                                        customerHashMap.put("First Name", firname);
                                        customerHashMap.put("Last Name", lasname);
                                        customerHashMap.put("EmailId", emaillid);
                                        customerHashMap.put("City", cityy);
                                        customerHashMap.put("Area", Area);
                                        customerHashMap.put("Password", passsword);
                                        customerHashMap.put("Pincode", Pincode);
                                        customerHashMap.put("State", statee);
                                        customerHashMap.put("Confirm Password", confdpassword);
                                        customerHashMap.put("Local Address", house);

                                        firebaseDatabase.getReference("Customer")
                                                .child(userId)
                                                .setValue(customerHashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        mDialog.dismiss();
                                                        if (task.isSuccessful()) {
                                                            fAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                    if (task.isSuccessful()) {
                                                                        AlertDialog.Builder builder = new AlertDialog.Builder(Registration.this);
                                                                        builder.setMessage("You have registered! Make sure to verify your email.");
                                                                        builder.setCancelable(false);
                                                                        builder.setPositiveButton("Ok", (dialog, which) -> {
                                                                            dialog.dismiss();
                                                                            String phonenumber = Country.getSelectedCountryCodeWithPlus() + mobile;
                                                                            Intent intent = new Intent(Registration.this, VerifyPhone.class);
                                                                            intent.putExtra("phonenumber", phonenumber);
                                                                            startActivity(intent);
                                                                        });
                                                                        AlertDialog alert = builder.create();
                                                                        alert.show();
                                                                    } else {
                                                                        ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                                                                    }
                                                                }
                                                            });
                                                        } else {
                                                            ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                                                        }
                                                    }
                                                });
                                    } else {
                                        mDialog.dismiss();
                                        ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                                    }
                                }
                            });
                        } else {
                            mDialog.dismiss();
                            ReusableCodeForAll.ShowAlert(Registration.this, "Error", task.getException().getMessage());
                        }
                    }
                });
            }
        });

        emailbutt.setOnClickListener(v -> {
            startActivity(new Intent(Registration.this, Login.class));
            finish();
        });

        Phonebutt.setOnClickListener(v -> {
            startActivity(new Intent(Registration.this, Loginphone.class));
            finish();
        });
    }

    private boolean isValid() {
        // Perform necessary validation checks
        if (TextUtils.isEmpty(firname)) {
            firstName.setError("First Name is required");
            return false;
        }
        if (TextUtils.isEmpty(lasname)) {
            Lastname.setError("Last Name is required");
            return false;
        }
        if (TextUtils.isEmpty(emaillid)) {
            eMailidle.setError("Email is required");
            return false;
        }
        if (TextUtils.isEmpty(passsword)) {
            pwdrd.setError("Password is required");
            return false;
        }
        if (TextUtils.isEmpty(confdpassword)) {
            cpwdrd.setError("Confirm Password is required");
            return false;
        }
        if (!passsword.equals(confdpassword)) {
            cpwdrd.setError("Passwords do not match");
            return false;
        }
        if (TextUtils.isEmpty(mobile)) {
            mobileNumber.setError("Mobile Number is required");
            return false;
        }
        if (TextUtils.isEmpty(Area)) {
            aarea.setError("Area is required");
            return false;
        }
        if (TextUtils.isEmpty(house)) {
            LocalAddress.setError("Local Address is required");
            return false;
        }
        if (TextUtils.isEmpty(Pincode)) {
            piiinCode.setError("Pincode is required");
            return false;
        }
        return true;
    }
}
